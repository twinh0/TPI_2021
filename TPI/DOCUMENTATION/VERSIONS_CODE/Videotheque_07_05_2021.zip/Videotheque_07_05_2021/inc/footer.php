<footer class="page-footer font-small footer-dark bg-dark" style="color:lightgrey;">

  <div class="footer-copyright text-center py-3 ">TPI 2021</div>

</footer>